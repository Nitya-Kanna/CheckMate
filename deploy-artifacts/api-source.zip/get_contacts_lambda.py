import json
from datetime import datetime

def handler(event, context):
    """
    Lambda function to get user contacts for bill splitting
    
    Query Parameters:
    - user_id: User ID (required)
    - search: Search query to filter contacts (optional)
    - limit: Number of contacts to return (default: 10, max: 50)
    """
    
    # Get query parameters
    query_params = event.get('queryStringParameters') or {}
    user_id = query_params.get('user_id')
    search_query = query_params.get('search', '').lower()
    limit = int(query_params.get('limit', 10))
    
    # Validate required parameters
    if not user_id:
        return {
            'statusCode': 400,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({
                'success': False,
                'error': 'Missing required parameter: user_id'
            })
        }
    
    # Validate limit
    if limit > 50:
        limit = 50
    
    # Mock contacts data
    all_contacts = [
        {
            'contact_id': 'contact_001',
            'name': 'Zin Ahmad',
            'phone': '+60123456789',
            'email': 'zin.ahmad@email.com',
            'avatar': 'https://ui-avatars.com/api/?name=Zin+Ahmad&background=0066CC&color=fff',
            'is_favorite': True,
            'last_split': '2026-04-20',
            'total_splits': 15,
            'relationship': 'friend'
        },
        {
            'contact_id': 'contact_002',
            'name': 'Lisa Tan',
            'phone': '+60129876543',
            'email': 'lisa.tan@email.com',
            'avatar': 'https://ui-avatars.com/api/?name=Lisa+Tan&background=FF6B9D&color=fff',
            'is_favorite': True,
            'last_split': '2026-04-22',
            'total_splits': 23,
            'relationship': 'friend'
        },
        {
            'contact_id': 'contact_003',
            'name': 'John Lee',
            'phone': '+60187654321',
            'email': 'john.lee@email.com',
            'avatar': 'https://ui-avatars.com/api/?name=John+Lee&background=4CAF50&color=fff',
            'is_favorite': False,
            'last_split': '2026-04-15',
            'total_splits': 8,
            'relationship': 'colleague'
        },
        {
            'contact_id': 'contact_004',
            'name': 'Sarah Wong',
            'phone': '+60162345678',
            'email': 'sarah.wong@email.com',
            'avatar': 'https://ui-avatars.com/api/?name=Sarah+Wong&background=9C27B0&color=fff',
            'is_favorite': True,
            'last_split': '2026-04-18',
            'total_splits': 12,
            'relationship': 'family'
        },
        {
            'contact_id': 'contact_005',
            'name': 'Mike Chen',
            'phone': '+60198765432',
            'email': 'mike.chen@email.com',
            'avatar': 'https://ui-avatars.com/api/?name=Mike+Chen&background=FF9800&color=fff',
            'is_favorite': False,
            'last_split': '2026-04-10',
            'total_splits': 5,
            'relationship': 'friend'
        }
    ]
    
    # Filter contacts by search query if provided
    filtered_contacts = all_contacts
    if search_query:
        filtered_contacts = [
            contact for contact in all_contacts
            if search_query in contact['name'].lower() or
               search_query in contact['email'].lower() or
               search_query in contact['phone']
        ]
    
    # Apply limit
    contacts = filtered_contacts[:limit]
    
    # Prepare response
    response_data = {
        'success': True,
        'contacts': contacts,
        'total_count': len(filtered_contacts),
        'returned_count': len(contacts),
        'search_query': search_query if search_query else None,
        'timestamp': datetime.utcnow().isoformat() + 'Z'
    }
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type'
        },
        'body': json.dumps(response_data)
    }

# Made with Bob
