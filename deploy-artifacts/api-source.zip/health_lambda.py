import json


def handler(event, context):
    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        "body": json.dumps(
            {
                "ok": True,
                "service": "bill-splitter-api",
                "message": "health check passed",
            }
        ),
    }
