# Mock Webhook (In-Memory Demo)

This is an isolated demo implementation using in-memory storage (no DynamoDB).

## Important limitation

In-memory data is ephemeral:

- resets on Lambda cold start/redeploy
- not shared across different Lambda instances

For a hackathon/demo, this is usually acceptable.

## Routes handled by one Lambda

- `POST /payments/requests`
- `GET /payments/requests/{payment_request_id}`
- `POST /mock/webhook/payment-update`

## Example flow

1. Create request (`pending`)
2. Poll GET endpoint from UI2 every 2s
3. Trigger mock webhook update (`paid`)
4. UI2 reflects new status on next poll
