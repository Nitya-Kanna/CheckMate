from threading import Lock


# In-memory store for demo only (resets on cold starts/redeploys).
_LOCK = Lock()
PAYMENT_REQUESTS = {}


def put_request(payment_request_id, payload):
    with _LOCK:
        PAYMENT_REQUESTS[payment_request_id] = payload
        return PAYMENT_REQUESTS[payment_request_id]


def get_request(payment_request_id):
    with _LOCK:
        return PAYMENT_REQUESTS.get(payment_request_id)


def update_request(payment_request_id, updater):
    with _LOCK:
        existing = PAYMENT_REQUESTS.get(payment_request_id)
        if not existing:
            return None
        PAYMENT_REQUESTS[payment_request_id] = updater(existing)
        return PAYMENT_REQUESTS[payment_request_id]
