import json
import time
import uuid

from storage import get_request, put_request, update_request


def _resp(code, payload):
    return {
        "statusCode": code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "content-type,authorization",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        },
        "body": json.dumps(payload),
    }


def _safe_body(event):
    raw = event.get("body")
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except Exception:
        return {}


def _create_payment_request(event):
    body = _safe_body(event)
    amount = float(body.get("amount", 0))
    if amount <= 0:
        return _resp(400, {"success": False, "message": "amount must be > 0"})

    request_id = f"pr_{uuid.uuid4().hex[:12]}"
    now = int(time.time())

    item = {
        "payment_request_id": request_id,
        "status": "pending",
        "amount": amount,
        "currency": body.get("currency", "MYR"),
        "payer_name": body.get("payer_name", "Unknown"),
        "payer_phone": body.get("payer_phone", "N/A"),
        "created_at": now,
        "updated_at": now,
        "webhook_events": [],
    }
    put_request(request_id, item)
    return _resp(201, {"success": True, "payment_request": item})


def _get_payment_request(event):
    payment_request_id = (event.get("pathParameters") or {}).get("payment_request_id")
    if not payment_request_id:
        return _resp(400, {"success": False, "message": "payment_request_id is required"})

    item = get_request(payment_request_id)
    if not item:
        return _resp(404, {"success": False, "message": "payment request not found"})

    return _resp(200, {"success": True, "payment_request": item})


def _mock_webhook_update(event):
    body = _safe_body(event)
    payment_request_id = body.get("payment_request_id")
    new_status = body.get("status", "paid")

    if not payment_request_id:
        return _resp(400, {"success": False, "message": "payment_request_id is required"})

    allowed = {"pending", "paid", "failed", "expired", "cancelled"}
    if new_status not in allowed:
        return _resp(400, {"success": False, "message": f"status must be one of {sorted(allowed)}"})

    now = int(time.time())
    event_item = {
        "event_id": f"evt_{uuid.uuid4().hex[:10]}",
        "event_type": "payment.request.updated",
        "status": new_status,
        "received_at": now,
    }

    updated = update_request(
        payment_request_id,
        lambda existing: {
            **existing,
            "status": new_status,
            "updated_at": now,
            "webhook_events": [*existing.get("webhook_events", []), event_item],
        },
    )

    if not updated:
        return _resp(404, {"success": False, "message": "payment request not found"})

    return _resp(200, {"success": True, "message": "mock webhook delivered", "payment_request": updated})


def handler(event, context):
    route_key = event.get("routeKey", "")

    if route_key == "POST /payments/requests":
        return _create_payment_request(event)
    if route_key == "GET /payments/requests/{payment_request_id}":
        return _get_payment_request(event)
    if route_key == "POST /mock/webhook/payment-update":
        return _mock_webhook_update(event)
    if route_key == "OPTIONS /payments/requests" or route_key == "OPTIONS /payments/requests/{payment_request_id}" or route_key == "OPTIONS /mock/webhook/payment-update":
        return _resp(200, {"success": True})

    return _resp(404, {"success": False, "message": f"route not found: {route_key}"})
