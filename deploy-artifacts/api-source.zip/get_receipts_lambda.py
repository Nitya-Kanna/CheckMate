import json
from datetime import datetime, timedelta


def handler(event, context):
    """
    Lambda function to get all receipts for a user
    
    Query Parameters:
    - user_id: User ID (required)
    - limit: Number of receipts to return (default: 20)
    - offset: Pagination offset (default: 0)
    - status: Filter by status (optional: all|ready_to_split|completed)
    """
    try:
        # Parse query parameters
        params = event.get('queryStringParameters', {}) or {}
        user_id = params.get('user_id')
        limit = int(params.get('limit', 20))
        offset = int(params.get('offset', 0))
        status_filter = params.get('status', 'all')
        
        if not user_id:
            return error_response(400, "Missing required parameter: user_id")
        
        # Mock receipts data (replace with DynamoDB query later)
        all_receipts = generate_mock_receipts()
        
        # Filter by status if specified
        if status_filter != 'all':
            all_receipts = [r for r in all_receipts if r['status'] == status_filter]
        
        # Pagination
        total_count = len(all_receipts)
        receipts = all_receipts[offset:offset + limit]
        has_more = (offset + limit) < total_count
        
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            "body": json.dumps({
                "success": True,
                "receipts": receipts,
                "total_count": total_count,
                "has_more": has_more,
                "limit": limit,
                "offset": offset
            })
        }
        
    except Exception as e:
        return error_response(500, f"Internal server error: {str(e)}")


def generate_mock_receipts():
    """Generate mock receipt data for testing"""
    base_date = datetime.now()
    
    receipts = [
        {
            "receipt_id": "rcpt_001",
            "user_id": "user_123",
            "restaurant_name": "RESTAURANT ABC",
            "date": (base_date - timedelta(days=0)).strftime("%Y-%m-%d"),
            "time": "15:30",
            "items": [
                {"name": "Nasi Lemak", "price": 12.00},
                {"name": "Pizza (Large)", "price": 35.00},
                {"name": "Iced Tea x2", "price": 8.00},
                {"name": "Chicken Burger", "price": 18.00},
                {"name": "French Fries", "price": 10.00},
                {"name": "Mango Smoothie", "price": 12.00}
            ],
            "subtotal": 95.00,
            "tax": 6.27,
            "service": 9.50,
            "total": 110.77,
            "items_count": 6,
            "status": "ready_to_split",
            "thumbnail": "https://via.placeholder.com/150",
            "created_at": (base_date - timedelta(days=0)).isoformat() + "Z"
        },
        {
            "receipt_id": "rcpt_002",
            "user_id": "user_123",
            "restaurant_name": "Cafe XYZ",
            "date": (base_date - timedelta(days=1)).strftime("%Y-%m-%d"),
            "time": "12:15",
            "items": [
                {"name": "Cappuccino", "price": 8.50},
                {"name": "Croissant", "price": 6.00},
                {"name": "Caesar Salad", "price": 15.00}
            ],
            "subtotal": 29.50,
            "tax": 1.95,
            "service": 2.95,
            "total": 34.40,
            "items_count": 3,
            "status": "completed",
            "thumbnail": "https://via.placeholder.com/150",
            "created_at": (base_date - timedelta(days=1)).isoformat() + "Z"
        },
        {
            "receipt_id": "rcpt_003",
            "user_id": "user_123",
            "restaurant_name": "Sushi House",
            "date": (base_date - timedelta(days=2)).strftime("%Y-%m-%d"),
            "time": "19:45",
            "items": [
                {"name": "Salmon Sashimi", "price": 28.00},
                {"name": "California Roll", "price": 18.00},
                {"name": "Miso Soup", "price": 5.00},
                {"name": "Green Tea", "price": 4.00}
            ],
            "subtotal": 55.00,
            "tax": 3.63,
            "service": 5.50,
            "total": 64.13,
            "items_count": 4,
            "status": "ready_to_split",
            "thumbnail": "https://via.placeholder.com/150",
            "created_at": (base_date - timedelta(days=2)).isoformat() + "Z"
        },
        {
            "receipt_id": "rcpt_004",
            "user_id": "user_123",
            "restaurant_name": "Burger Joint",
            "date": (base_date - timedelta(days=3)).strftime("%Y-%m-%d"),
            "time": "13:20",
            "items": [
                {"name": "Classic Burger", "price": 15.00},
                {"name": "Cheese Fries", "price": 8.00},
                {"name": "Milkshake", "price": 7.00}
            ],
            "subtotal": 30.00,
            "tax": 1.98,
            "service": 3.00,
            "total": 34.98,
            "items_count": 3,
            "status": "completed",
            "thumbnail": "https://via.placeholder.com/150",
            "created_at": (base_date - timedelta(days=3)).isoformat() + "Z"
        }
    ]
    
    return receipts


def error_response(status_code, message):
    """Return error response"""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        "body": json.dumps({
            "success": False,
            "error": message
        })
    }

# Made with Bob
