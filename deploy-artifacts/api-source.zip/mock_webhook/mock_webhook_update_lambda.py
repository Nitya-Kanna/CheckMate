import json
import os
import time
import uuid
from decimal import Decimal

import boto3


TABLE_NAME = os.environ.get("TABLE_NAME", "bill-splitter-mock-requests")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)


def _response(status_code, payload):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "content-type,authorization",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        },
        "body": json.dumps(payload),
    }


def _decimal_to_native(value):
    if isinstance(value, list):
        return [_decimal_to_native(v) for v in value]
    if isinstance(value, dict):
        return {k: _decimal_to_native(v) for k, v in value.items()}
    if isinstance(value, Decimal):
        if value % 1 == 0:
            return int(value)
        return float(value)
    return value


def handler(event, context):
    body = json.loads(event.get("body") or "{}")
    payment_request_id = body.get("payment_request_id")
    new_status = body.get("status", "paid")

    if not payment_request_id:
        return _response(400, {"success": False, "message": "payment_request_id is required"})

    allowed = {"pending", "paid", "failed", "expired", "cancelled"}
    if new_status not in allowed:
        return _response(400, {"success": False, "message": f"status must be one of {sorted(allowed)}"})

    now = int(time.time())
    webhook_event = {
        "event_id": f"evt_{uuid.uuid4().hex[:10]}",
        "event_type": "payment.request.updated",
        "status": new_status,
        "received_at": now,
    }

    try:
        result = table.update_item(
            Key={"payment_request_id": payment_request_id},
            UpdateExpression="SET #s = :s, updated_at = :u, webhook_events = list_append(if_not_exists(webhook_events, :empty), :evt)",
            ConditionExpression="attribute_exists(payment_request_id)",
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={
                ":s": new_status,
                ":u": now,
                ":evt": [webhook_event],
                ":empty": [],
            },
            ReturnValues="ALL_NEW",
        )
    except Exception:
        return _response(404, {"success": False, "message": "payment request not found"})

    return _response(
        200,
        {
            "success": True,
            "message": "mock webhook delivered",
            "payment_request": _decimal_to_native(result["Attributes"]),
        },
    )
