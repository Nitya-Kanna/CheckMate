import json
import os
from decimal import Decimal

import boto3


TABLE_NAME = os.environ.get("TABLE_NAME", "bill-splitter-mock-requests")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)


def _decimal_to_native(value):
    if isinstance(value, list):
        return [_decimal_to_native(v) for v in value]
    if isinstance(value, dict):
        return {k: _decimal_to_native(v) for k, v in value.items()}
    if isinstance(value, Decimal):
        if value % 1 == 0:
            return int(value)
        return float(value)
    return value


def _response(status_code, payload):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "content-type,authorization",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        },
        "body": json.dumps(payload),
    }


def handler(event, context):
    path_params = event.get("pathParameters") or {}
    payment_request_id = path_params.get("payment_request_id")

    if not payment_request_id:
        return _response(400, {"success": False, "message": "payment_request_id is required"})

    result = table.get_item(Key={"payment_request_id": payment_request_id})
    item = result.get("Item")

    if not item:
        return _response(404, {"success": False, "message": "payment request not found"})

    return _response(200, {"success": True, "payment_request": _decimal_to_native(item)})
