import json
import os
import time
import uuid
from decimal import Decimal

import boto3


TABLE_NAME = os.environ.get("TABLE_NAME", "bill-splitter-mock-requests")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)


def _response(status_code, payload):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "content-type,authorization",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        },
        "body": json.dumps(payload),
    }


def _to_decimal(value):
    return Decimal(str(value))


def handler(event, context):
    body = json.loads(event.get("body") or "{}")

    payer_name = body.get("payer_name", "Unknown")
    payer_phone = body.get("payer_phone", "N/A")
    amount = body.get("amount", 0)
    currency = body.get("currency", "MYR")

    if amount is None or float(amount) <= 0:
        return _response(400, {"success": False, "message": "amount must be greater than 0"})

    payment_request_id = f"pr_{uuid.uuid4().hex[:12]}"
    now = int(time.time())

    item = {
        "payment_request_id": payment_request_id,
        "status": "pending",
        "payer_name": payer_name,
        "payer_phone": payer_phone,
        "amount": _to_decimal(amount),
        "currency": currency,
        "created_at": now,
        "updated_at": now,
        "webhook_events": [],
    }

    table.put_item(Item=item)

    return _response(
        201,
        {
            "success": True,
            "payment_request_id": payment_request_id,
            "status": "pending",
            "amount": float(item["amount"]),
            "currency": currency,
            "payer_name": payer_name,
            "payer_phone": payer_phone,
        },
    )
