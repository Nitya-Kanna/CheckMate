# Mock Webhook Demo (Isolated Files)

This folder is intentionally separate from existing handlers so it is easy to review.

## Files

- `create_payment_request_lambda.py` -> `POST /payments/requests`
- `get_payment_request_lambda.py` -> `GET /payments/requests/{payment_request_id}`
- `mock_webhook_update_lambda.py` -> `POST /mock/webhook/payment-update`

## Demo Flow

1. UI1 creates request using `POST /payments/requests` (status starts as `pending`).
2. UI2 polls `GET /payments/requests/{id}` every 2s.
3. Trigger mock webhook via `POST /mock/webhook/payment-update` with status `paid`.
4. UI2 sees status change on next poll and updates.

## Sample Requests

Create:

```bash
curl -X POST "$API_BASE/payments/requests" \
  -H "Content-Type: application/json" \
  -d '{"payer_name":"Zin","payer_phone":"+60123456789","amount":26.73,"currency":"MYR"}'
```

Get:

```bash
curl "$API_BASE/payments/requests/<payment_request_id>"
```

Mock webhook:

```bash
curl -X POST "$API_BASE/mock/webhook/payment-update" \
  -H "Content-Type: application/json" \
  -d '{"payment_request_id":"<payment_request_id>","status":"paid"}'
```
