"""
Lambda handler for POST /ai/parse-bill
Dummy AI parser - returns mock parsed data
TODO: Replace with real Alibaba DashScope integration
"""
import json
from utils import success_response, error_response

def lambda_handler(event, context):
    """
    Parse natural language input to match people with receipt items
    
    Request body:
    {
        "input": "zin ate nasi lemak, lisa ate pizza",
        "receipt_items": [
            {"name": "Nasi Lemak", "price": 8.50},
            {"name": "Pizza", "price": 25.00}
        ]
    }
    
    Response:
    {
        "parsed": [
            {
                "person": "zin",
                "items": ["Nasi Lemak"],
                "total": 8.50
            },
            {
                "person": "lisa",
                "items": ["Pizza"],
                "total": 25.00
            }
        ]
    }
    """
    try:
        # Parse request body
        body = json.loads(event.get('body', '{}'))
        input_text = body.get('input', '')
        receipt_items = body.get('receipt_items', [])
        
        if not input_text:
            return error_response(400, 'Missing input text')
        
        if not receipt_items:
            return error_response(400, 'Missing receipt items')
        
        # DUMMY PARSING - Simple keyword matching
        # TODO: Replace with Alibaba DashScope API call
        parsed_data = []
        
        # Split input by comma or "and"
        input_lower = input_text.lower()
        statements = input_lower.replace(' and ', ',').split(',')
        
        for statement in statements:
            statement = statement.strip()
            
            # Extract person name (first word)
            words = statement.split()
            if len(words) < 2:
                continue
                
            person = words[0].strip()
            
            # Find matching items
            matched_items = []
            total = 0.0
            
            for item in receipt_items:
                item_name = item.get('name', '').lower()
                # Check if item name is mentioned in statement
                if item_name in statement:
                    matched_items.append(item.get('name'))
                    total += float(item.get('price', 0))
            
            if matched_items:
                parsed_data.append({
                    'person': person.capitalize(),
                    'items': matched_items,
                    'total': round(total, 2)
                })
        
        # If no matches found, return error
        if not parsed_data:
            return error_response(400, 'Could not parse input. Try: "zin ate nasi lemak, lisa ate pizza"')
        
        return success_response({
            'parsed': parsed_data,
            'original_input': input_text,
            'note': 'This is a dummy parser. Real AI integration coming soon.'
        })
        
    except json.JSONDecodeError:
        return error_response(400, 'Invalid JSON in request body')
    except Exception as e:
        print(f"Error parsing bill: {str(e)}")
        return error_response(500, f'Internal server error: {str(e)}')

# Made with Bob
